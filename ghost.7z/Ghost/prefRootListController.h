#import <Preferences/PSListController.h>

@interface prefRootListController : PSListController

@end
